var searchData=
[
  ['mode',['mode',['../mainwindow_8cpp.html#a1ea5d0cb93f22f7d0fdf804bd68c3326',1,'mainwindow.cpp']]]
];
