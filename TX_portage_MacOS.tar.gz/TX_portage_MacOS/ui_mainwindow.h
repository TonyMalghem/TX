/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.3.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QRadioButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionRC4;
    QAction *actionAES;
    QAction *actionRSA;
    QAction *actionAbout;
    QAction *actionCipher;
    QAction *actionDecipher;
    QWidget *centralWidget;
    QTextEdit *textEdit_inputText;
    QLabel *label_cipher;
    QLabel *label_key;
    QTextEdit *textEdit_key;
    QPushButton *pushButton_cipher;
    QTextBrowser *textBrowser_ciphered;
    QTextBrowser *textBrowser_input0;
    QTextBrowser *textBrowser_input1;
    QTextBrowser *textBrowser_input2;
    QTextBrowser *textBrowser_input3;
    QTextBrowser *textBrowser_input4;
    QTextBrowser *textBrowser_keystream0;
    QTextBrowser *textBrowser_keystream1;
    QTextBrowser *textBrowser_keystream4;
    QTextBrowser *textBrowser_keystream2;
    QTextBrowser *textBrowser_keystream3;
    QTextBrowser *textBrowser_result0;
    QTextBrowser *textBrowser_result1;
    QTextBrowser *textBrowser_result4;
    QTextBrowser *textBrowser_result2;
    QTextBrowser *textBrowser_result3;
    QLabel *label_xor;
    QLabel *label_equal;
    QLabel *label_textbox;
    QLabel *label_keystreambox;
    QLabel *label_res;
    QLabel *label_final;
    QPushButton *pushButton_decipher;
    QLabel *label_decipher;
    QRadioButton *radioButton_hexa;
    QRadioButton *radioButton_string;
    QLabel *label_inputmode;
    QTextEdit *textEdit_inputTextHex;
    QLabel *label_inputHex;
    QLabel *label_finalPlain;
    QTextBrowser *textBrowser_cipheredPlain;
    QLabel *label_xor1;
    QLabel *label_equal1;
    QLabel *label_xor2;
    QLabel *label_equal2;
    QLabel *label_xor3;
    QLabel *label_equal3;
    QLabel *label_xor4;
    QLabel *label_equal4;
    QPushButton *pushButton_image;
    QLabel *label_image;
    QPushButton *pushButton_back;
    QTextBrowser *textBrowser_img0;
    QTextBrowser *textBrowser_img1;
    QTextBrowser *textBrowser_img2;
    QTextBrowser *textBrowser_img3;
    QTextBrowser *textBrowser_img4;
    QTextBrowser *textBrowser_img5;
    QTextBrowser *textBrowser_img6;
    QTextBrowser *textBrowser_img7;
    QTextBrowser *textBrowser_img91;
    QTextBrowser *textBrowser_img8;
    QTextBrowser *textBrowser_img99;
    QTextEdit *textEdit_RSA_p;
    QLabel *label_RSA_p;
    QLabel *label_RSA_q;
    QTextEdit *textEdit_RSA_q;
    QLabel *label_RSA_M;
    QTextEdit *textEdit_RSA_M;
    QTextBrowser *textBrowser_RSA_m;
    QLabel *label_RSA_m;
    QLabel *label_index;
    QLabel *label_RSA_n;
    QLabel *label_p;
    QLabel *label_times;
    QLabel *label_q;
    QLabel *label_eq;
    QLabel *label_pq;
    QLabel *label_pmoins1;
    QLabel *label_times_2;
    QLabel *label_pmoins1_res;
    QLabel *label_eq_2;
    QLabel *label_RSA_phi_n;
    QLabel *label_qmoins1;
    QLabel *label_eq_3;
    QLabel *label_qmoins1_res;
    QLabel *label_times_3;
    QLabel *label_phi_n_res;
    QLabel *label_calcE;
    QLabel *label_calcC;
    QTextBrowser *textBrowser_RSA_e;
    QTextBrowser *textBrowser_RSA_c1;
    QLabel *label_RSA_e_in;
    QTextEdit *textEdit_RSA_c_in;
    QTextEdit *textEdit_RSA_e_in;
    QLabel *label_RSA_c_in;
    QMenuBar *menuBar;
    QMenu *menuMode;
    QMenu *menuAbout;
    QMenu *menuMode_2;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1250, 594);
        actionRC4 = new QAction(MainWindow);
        actionRC4->setObjectName(QStringLiteral("actionRC4"));
        actionAES = new QAction(MainWindow);
        actionAES->setObjectName(QStringLiteral("actionAES"));
        actionRSA = new QAction(MainWindow);
        actionRSA->setObjectName(QStringLiteral("actionRSA"));
        actionAbout = new QAction(MainWindow);
        actionAbout->setObjectName(QStringLiteral("actionAbout"));
        actionCipher = new QAction(MainWindow);
        actionCipher->setObjectName(QStringLiteral("actionCipher"));
        actionDecipher = new QAction(MainWindow);
        actionDecipher->setObjectName(QStringLiteral("actionDecipher"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        textEdit_inputText = new QTextEdit(centralWidget);
        textEdit_inputText->setObjectName(QStringLiteral("textEdit_inputText"));
        textEdit_inputText->setGeometry(QRect(10, 30, 1221, 91));
        label_cipher = new QLabel(centralWidget);
        label_cipher->setObjectName(QStringLiteral("label_cipher"));
        label_cipher->setGeometry(QRect(10, 10, 101, 16));
        label_key = new QLabel(centralWidget);
        label_key->setObjectName(QStringLiteral("label_key"));
        label_key->setGeometry(QRect(10, 130, 41, 16));
        textEdit_key = new QTextEdit(centralWidget);
        textEdit_key->setObjectName(QStringLiteral("textEdit_key"));
        textEdit_key->setGeometry(QRect(10, 150, 1221, 31));
        pushButton_cipher = new QPushButton(centralWidget);
        pushButton_cipher->setObjectName(QStringLiteral("pushButton_cipher"));
        pushButton_cipher->setGeometry(QRect(10, 190, 121, 22));
        textBrowser_ciphered = new QTextBrowser(centralWidget);
        textBrowser_ciphered->setObjectName(QStringLiteral("textBrowser_ciphered"));
        textBrowser_ciphered->setGeometry(QRect(280, 330, 501, 191));
        textBrowser_input0 = new QTextBrowser(centralWidget);
        textBrowser_input0->setObjectName(QStringLiteral("textBrowser_input0"));
        textBrowser_input0->setGeometry(QRect(20, 330, 41, 31));
        textBrowser_input1 = new QTextBrowser(centralWidget);
        textBrowser_input1->setObjectName(QStringLiteral("textBrowser_input1"));
        textBrowser_input1->setGeometry(QRect(20, 370, 41, 31));
        textBrowser_input2 = new QTextBrowser(centralWidget);
        textBrowser_input2->setObjectName(QStringLiteral("textBrowser_input2"));
        textBrowser_input2->setGeometry(QRect(20, 410, 41, 31));
        textBrowser_input3 = new QTextBrowser(centralWidget);
        textBrowser_input3->setObjectName(QStringLiteral("textBrowser_input3"));
        textBrowser_input3->setGeometry(QRect(20, 450, 41, 31));
        textBrowser_input4 = new QTextBrowser(centralWidget);
        textBrowser_input4->setObjectName(QStringLiteral("textBrowser_input4"));
        textBrowser_input4->setGeometry(QRect(20, 490, 41, 31));
        textBrowser_keystream0 = new QTextBrowser(centralWidget);
        textBrowser_keystream0->setObjectName(QStringLiteral("textBrowser_keystream0"));
        textBrowser_keystream0->setGeometry(QRect(120, 330, 41, 31));
        textBrowser_keystream1 = new QTextBrowser(centralWidget);
        textBrowser_keystream1->setObjectName(QStringLiteral("textBrowser_keystream1"));
        textBrowser_keystream1->setGeometry(QRect(120, 370, 41, 31));
        textBrowser_keystream4 = new QTextBrowser(centralWidget);
        textBrowser_keystream4->setObjectName(QStringLiteral("textBrowser_keystream4"));
        textBrowser_keystream4->setGeometry(QRect(120, 490, 41, 31));
        textBrowser_keystream2 = new QTextBrowser(centralWidget);
        textBrowser_keystream2->setObjectName(QStringLiteral("textBrowser_keystream2"));
        textBrowser_keystream2->setGeometry(QRect(120, 410, 41, 31));
        textBrowser_keystream3 = new QTextBrowser(centralWidget);
        textBrowser_keystream3->setObjectName(QStringLiteral("textBrowser_keystream3"));
        textBrowser_keystream3->setGeometry(QRect(120, 450, 41, 31));
        textBrowser_result0 = new QTextBrowser(centralWidget);
        textBrowser_result0->setObjectName(QStringLiteral("textBrowser_result0"));
        textBrowser_result0->setGeometry(QRect(210, 330, 41, 31));
        textBrowser_result1 = new QTextBrowser(centralWidget);
        textBrowser_result1->setObjectName(QStringLiteral("textBrowser_result1"));
        textBrowser_result1->setGeometry(QRect(210, 370, 41, 31));
        textBrowser_result4 = new QTextBrowser(centralWidget);
        textBrowser_result4->setObjectName(QStringLiteral("textBrowser_result4"));
        textBrowser_result4->setGeometry(QRect(210, 490, 41, 31));
        textBrowser_result2 = new QTextBrowser(centralWidget);
        textBrowser_result2->setObjectName(QStringLiteral("textBrowser_result2"));
        textBrowser_result2->setGeometry(QRect(210, 410, 41, 31));
        textBrowser_result3 = new QTextBrowser(centralWidget);
        textBrowser_result3->setObjectName(QStringLiteral("textBrowser_result3"));
        textBrowser_result3->setGeometry(QRect(210, 450, 41, 31));
        label_xor = new QLabel(centralWidget);
        label_xor->setObjectName(QStringLiteral("label_xor"));
        label_xor->setGeometry(QRect(80, 340, 31, 16));
        label_equal = new QLabel(centralWidget);
        label_equal->setObjectName(QStringLiteral("label_equal"));
        label_equal->setGeometry(QRect(180, 340, 21, 16));
        label_textbox = new QLabel(centralWidget);
        label_textbox->setObjectName(QStringLiteral("label_textbox"));
        label_textbox->setGeometry(QRect(20, 300, 31, 16));
        label_keystreambox = new QLabel(centralWidget);
        label_keystreambox->setObjectName(QStringLiteral("label_keystreambox"));
        label_keystreambox->setGeometry(QRect(110, 300, 71, 16));
        label_res = new QLabel(centralWidget);
        label_res->setObjectName(QStringLiteral("label_res"));
        label_res->setGeometry(QRect(210, 300, 51, 16));
        label_final = new QLabel(centralWidget);
        label_final->setObjectName(QStringLiteral("label_final"));
        label_final->setGeometry(QRect(280, 300, 131, 16));
        pushButton_decipher = new QPushButton(centralWidget);
        pushButton_decipher->setObjectName(QStringLiteral("pushButton_decipher"));
        pushButton_decipher->setEnabled(false);
        pushButton_decipher->setGeometry(QRect(140, 190, 121, 22));
        label_decipher = new QLabel(centralWidget);
        label_decipher->setObjectName(QStringLiteral("label_decipher"));
        label_decipher->setEnabled(true);
        label_decipher->setGeometry(QRect(10, 10, 121, 16));
        radioButton_hexa = new QRadioButton(centralWidget);
        radioButton_hexa->setObjectName(QStringLiteral("radioButton_hexa"));
        radioButton_hexa->setGeometry(QRect(520, 10, 71, 20));
        radioButton_string = new QRadioButton(centralWidget);
        radioButton_string->setObjectName(QStringLiteral("radioButton_string"));
        radioButton_string->setGeometry(QRect(610, 10, 71, 20));
        label_inputmode = new QLabel(centralWidget);
        label_inputmode->setObjectName(QStringLiteral("label_inputmode"));
        label_inputmode->setGeometry(QRect(410, 10, 81, 16));
        textEdit_inputTextHex = new QTextEdit(centralWidget);
        textEdit_inputTextHex->setObjectName(QStringLiteral("textEdit_inputTextHex"));
        textEdit_inputTextHex->setGeometry(QRect(10, 240, 1221, 31));
        label_inputHex = new QLabel(centralWidget);
        label_inputHex->setObjectName(QStringLiteral("label_inputHex"));
        label_inputHex->setGeometry(QRect(10, 220, 91, 16));
        label_finalPlain = new QLabel(centralWidget);
        label_finalPlain->setObjectName(QStringLiteral("label_finalPlain"));
        label_finalPlain->setGeometry(QRect(800, 300, 171, 16));
        textBrowser_cipheredPlain = new QTextBrowser(centralWidget);
        textBrowser_cipheredPlain->setObjectName(QStringLiteral("textBrowser_cipheredPlain"));
        textBrowser_cipheredPlain->setGeometry(QRect(800, 330, 431, 191));
        label_xor1 = new QLabel(centralWidget);
        label_xor1->setObjectName(QStringLiteral("label_xor1"));
        label_xor1->setGeometry(QRect(80, 380, 31, 16));
        label_equal1 = new QLabel(centralWidget);
        label_equal1->setObjectName(QStringLiteral("label_equal1"));
        label_equal1->setGeometry(QRect(180, 380, 21, 16));
        label_xor2 = new QLabel(centralWidget);
        label_xor2->setObjectName(QStringLiteral("label_xor2"));
        label_xor2->setGeometry(QRect(80, 420, 31, 16));
        label_equal2 = new QLabel(centralWidget);
        label_equal2->setObjectName(QStringLiteral("label_equal2"));
        label_equal2->setGeometry(QRect(180, 420, 21, 16));
        label_xor3 = new QLabel(centralWidget);
        label_xor3->setObjectName(QStringLiteral("label_xor3"));
        label_xor3->setGeometry(QRect(80, 460, 31, 16));
        label_equal3 = new QLabel(centralWidget);
        label_equal3->setObjectName(QStringLiteral("label_equal3"));
        label_equal3->setGeometry(QRect(180, 460, 21, 16));
        label_xor4 = new QLabel(centralWidget);
        label_xor4->setObjectName(QStringLiteral("label_xor4"));
        label_xor4->setGeometry(QRect(80, 500, 31, 16));
        label_equal4 = new QLabel(centralWidget);
        label_equal4->setObjectName(QStringLiteral("label_equal4"));
        label_equal4->setGeometry(QRect(180, 500, 21, 16));
        pushButton_image = new QPushButton(centralWidget);
        pushButton_image->setObjectName(QStringLiteral("pushButton_image"));
        pushButton_image->setGeometry(QRect(440, 290, 171, 23));
        label_image = new QLabel(centralWidget);
        label_image->setObjectName(QStringLiteral("label_image"));
        label_image->setGeometry(QRect(40, 10, 1181, 541));
        pushButton_back = new QPushButton(centralWidget);
        pushButton_back->setObjectName(QStringLiteral("pushButton_back"));
        pushButton_back->setGeometry(QRect(1140, 290, 75, 23));
        textBrowser_img0 = new QTextBrowser(centralWidget);
        textBrowser_img0->setObjectName(QStringLiteral("textBrowser_img0"));
        textBrowser_img0->setGeometry(QRect(450, 70, 41, 31));
        textBrowser_img1 = new QTextBrowser(centralWidget);
        textBrowser_img1->setObjectName(QStringLiteral("textBrowser_img1"));
        textBrowser_img1->setGeometry(QRect(550, 70, 41, 31));
        textBrowser_img2 = new QTextBrowser(centralWidget);
        textBrowser_img2->setObjectName(QStringLiteral("textBrowser_img2"));
        textBrowser_img2->setGeometry(QRect(450, 140, 41, 31));
        textBrowser_img3 = new QTextBrowser(centralWidget);
        textBrowser_img3->setObjectName(QStringLiteral("textBrowser_img3"));
        textBrowser_img3->setGeometry(QRect(550, 140, 41, 31));
        textBrowser_img4 = new QTextBrowser(centralWidget);
        textBrowser_img4->setObjectName(QStringLiteral("textBrowser_img4"));
        textBrowser_img4->setGeometry(QRect(450, 200, 41, 31));
        textBrowser_img5 = new QTextBrowser(centralWidget);
        textBrowser_img5->setObjectName(QStringLiteral("textBrowser_img5"));
        textBrowser_img5->setGeometry(QRect(550, 200, 41, 31));
        textBrowser_img6 = new QTextBrowser(centralWidget);
        textBrowser_img6->setObjectName(QStringLiteral("textBrowser_img6"));
        textBrowser_img6->setGeometry(QRect(350, 260, 41, 31));
        textBrowser_img7 = new QTextBrowser(centralWidget);
        textBrowser_img7->setObjectName(QStringLiteral("textBrowser_img7"));
        textBrowser_img7->setGeometry(QRect(760, 170, 31, 31));
        textBrowser_img91 = new QTextBrowser(centralWidget);
        textBrowser_img91->setObjectName(QStringLiteral("textBrowser_img91"));
        textBrowser_img91->setGeometry(QRect(760, 210, 31, 31));
        textBrowser_img8 = new QTextBrowser(centralWidget);
        textBrowser_img8->setObjectName(QStringLiteral("textBrowser_img8"));
        textBrowser_img8->setGeometry(QRect(810, 170, 31, 31));
        textBrowser_img99 = new QTextBrowser(centralWidget);
        textBrowser_img99->setObjectName(QStringLiteral("textBrowser_img99"));
        textBrowser_img99->setGeometry(QRect(810, 210, 31, 31));
        textEdit_RSA_p = new QTextEdit(centralWidget);
        textEdit_RSA_p->setObjectName(QStringLiteral("textEdit_RSA_p"));
        textEdit_RSA_p->setGeometry(QRect(10, 30, 591, 31));
        label_RSA_p = new QLabel(centralWidget);
        label_RSA_p->setObjectName(QStringLiteral("label_RSA_p"));
        label_RSA_p->setEnabled(true);
        label_RSA_p->setGeometry(QRect(10, 10, 201, 16));
        label_RSA_q = new QLabel(centralWidget);
        label_RSA_q->setObjectName(QStringLiteral("label_RSA_q"));
        label_RSA_q->setEnabled(true);
        label_RSA_q->setGeometry(QRect(640, 10, 221, 16));
        textEdit_RSA_q = new QTextEdit(centralWidget);
        textEdit_RSA_q->setObjectName(QStringLiteral("textEdit_RSA_q"));
        textEdit_RSA_q->setGeometry(QRect(640, 30, 591, 31));
        label_RSA_M = new QLabel(centralWidget);
        label_RSA_M->setObjectName(QStringLiteral("label_RSA_M"));
        label_RSA_M->setEnabled(true);
        label_RSA_M->setGeometry(QRect(10, 130, 221, 16));
        textEdit_RSA_M = new QTextEdit(centralWidget);
        textEdit_RSA_M->setObjectName(QStringLiteral("textEdit_RSA_M"));
        textEdit_RSA_M->setGeometry(QRect(10, 150, 1221, 31));
        textBrowser_RSA_m = new QTextBrowser(centralWidget);
        textBrowser_RSA_m->setObjectName(QStringLiteral("textBrowser_RSA_m"));
        textBrowser_RSA_m->setGeometry(QRect(10, 240, 1221, 31));
        label_RSA_m = new QLabel(centralWidget);
        label_RSA_m->setObjectName(QStringLiteral("label_RSA_m"));
        label_RSA_m->setGeometry(QRect(10, 220, 261, 16));
        label_index = new QLabel(centralWidget);
        label_index->setObjectName(QStringLiteral("label_index"));
        label_index->setGeometry(QRect(450, 80, 321, 21));
        label_RSA_n = new QLabel(centralWidget);
        label_RSA_n->setObjectName(QStringLiteral("label_RSA_n"));
        label_RSA_n->setGeometry(QRect(20, 280, 41, 16));
        label_p = new QLabel(centralWidget);
        label_p->setObjectName(QStringLiteral("label_p"));
        label_p->setGeometry(QRect(50, 280, 61, 16));
        label_times = new QLabel(centralWidget);
        label_times->setObjectName(QStringLiteral("label_times"));
        label_times->setGeometry(QRect(120, 280, 20, 16));
        label_q = new QLabel(centralWidget);
        label_q->setObjectName(QStringLiteral("label_q"));
        label_q->setGeometry(QRect(140, 280, 61, 16));
        label_eq = new QLabel(centralWidget);
        label_eq->setObjectName(QStringLiteral("label_eq"));
        label_eq->setGeometry(QRect(210, 280, 20, 16));
        label_pq = new QLabel(centralWidget);
        label_pq->setObjectName(QStringLiteral("label_pq"));
        label_pq->setGeometry(QRect(230, 280, 61, 16));
        label_pmoins1 = new QLabel(centralWidget);
        label_pmoins1->setObjectName(QStringLiteral("label_pmoins1"));
        label_pmoins1->setGeometry(QRect(430, 280, 61, 16));
        label_times_2 = new QLabel(centralWidget);
        label_times_2->setObjectName(QStringLiteral("label_times_2"));
        label_times_2->setGeometry(QRect(500, 280, 20, 16));
        label_pmoins1_res = new QLabel(centralWidget);
        label_pmoins1_res->setObjectName(QStringLiteral("label_pmoins1_res"));
        label_pmoins1_res->setGeometry(QRect(610, 280, 61, 16));
        label_eq_2 = new QLabel(centralWidget);
        label_eq_2->setObjectName(QStringLiteral("label_eq_2"));
        label_eq_2->setGeometry(QRect(590, 280, 20, 16));
        label_RSA_phi_n = new QLabel(centralWidget);
        label_RSA_phi_n->setObjectName(QStringLiteral("label_RSA_phi_n"));
        label_RSA_phi_n->setGeometry(QRect(380, 280, 41, 16));
        label_qmoins1 = new QLabel(centralWidget);
        label_qmoins1->setObjectName(QStringLiteral("label_qmoins1"));
        label_qmoins1->setGeometry(QRect(520, 280, 61, 16));
        label_eq_3 = new QLabel(centralWidget);
        label_eq_3->setObjectName(QStringLiteral("label_eq_3"));
        label_eq_3->setGeometry(QRect(770, 280, 20, 16));
        label_qmoins1_res = new QLabel(centralWidget);
        label_qmoins1_res->setObjectName(QStringLiteral("label_qmoins1_res"));
        label_qmoins1_res->setGeometry(QRect(700, 280, 61, 16));
        label_times_3 = new QLabel(centralWidget);
        label_times_3->setObjectName(QStringLiteral("label_times_3"));
        label_times_3->setGeometry(QRect(680, 280, 20, 16));
        label_phi_n_res = new QLabel(centralWidget);
        label_phi_n_res->setObjectName(QStringLiteral("label_phi_n_res"));
        label_phi_n_res->setGeometry(QRect(790, 280, 61, 16));
        label_calcE = new QLabel(centralWidget);
        label_calcE->setObjectName(QStringLiteral("label_calcE"));
        label_calcE->setGeometry(QRect(20, 300, 221, 16));
        label_calcC = new QLabel(centralWidget);
        label_calcC->setObjectName(QStringLiteral("label_calcC"));
        label_calcC->setGeometry(QRect(610, 300, 261, 16));
        textBrowser_RSA_e = new QTextBrowser(centralWidget);
        textBrowser_RSA_e->setObjectName(QStringLiteral("textBrowser_RSA_e"));
        textBrowser_RSA_e->setGeometry(QRect(20, 330, 561, 31));
        textBrowser_RSA_c1 = new QTextBrowser(centralWidget);
        textBrowser_RSA_c1->setObjectName(QStringLiteral("textBrowser_RSA_c1"));
        textBrowser_RSA_c1->setGeometry(QRect(610, 330, 621, 31));
        label_RSA_e_in = new QLabel(centralWidget);
        label_RSA_e_in->setObjectName(QStringLiteral("label_RSA_e_in"));
        label_RSA_e_in->setEnabled(true);
        label_RSA_e_in->setGeometry(QRect(10, 70, 201, 16));
        textEdit_RSA_c_in = new QTextEdit(centralWidget);
        textEdit_RSA_c_in->setObjectName(QStringLiteral("textEdit_RSA_c_in"));
        textEdit_RSA_c_in->setGeometry(QRect(640, 90, 591, 31));
        textEdit_RSA_e_in = new QTextEdit(centralWidget);
        textEdit_RSA_e_in->setObjectName(QStringLiteral("textEdit_RSA_e_in"));
        textEdit_RSA_e_in->setGeometry(QRect(10, 90, 591, 31));
        label_RSA_c_in = new QLabel(centralWidget);
        label_RSA_c_in->setObjectName(QStringLiteral("label_RSA_c_in"));
        label_RSA_c_in->setEnabled(true);
        label_RSA_c_in->setGeometry(QRect(640, 70, 221, 16));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1250, 19));
        menuMode = new QMenu(menuBar);
        menuMode->setObjectName(QStringLiteral("menuMode"));
        menuAbout = new QMenu(menuBar);
        menuAbout->setObjectName(QStringLiteral("menuAbout"));
        menuMode_2 = new QMenu(menuBar);
        menuMode_2->setObjectName(QStringLiteral("menuMode_2"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuMode_2->menuAction());
        menuBar->addAction(menuMode->menuAction());
        menuBar->addAction(menuAbout->menuAction());
        menuMode->addAction(actionRC4);
        menuMode->addAction(actionRSA);
        menuAbout->addAction(actionAbout);
        menuMode_2->addAction(actionCipher);
        menuMode_2->addAction(actionDecipher);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        actionRC4->setText(QApplication::translate("MainWindow", "RC4", 0));
        actionAES->setText(QApplication::translate("MainWindow", "AES", 0));
        actionRSA->setText(QApplication::translate("MainWindow", "RSA", 0));
        actionAbout->setText(QApplication::translate("MainWindow", "About", 0));
        actionCipher->setText(QApplication::translate("MainWindow", "Cipher", 0));
        actionDecipher->setText(QApplication::translate("MainWindow", "Decipher", 0));
        label_cipher->setText(QApplication::translate("MainWindow", "Text to cipher:", 0));
        label_key->setText(QApplication::translate("MainWindow", "Key :", 0));
        pushButton_cipher->setText(QApplication::translate("MainWindow", "Cipher", 0));
        label_xor->setText(QApplication::translate("MainWindow", "XOR", 0));
        label_equal->setText(QApplication::translate("MainWindow", "=", 0));
        label_textbox->setText(QApplication::translate("MainWindow", "Text", 0));
        label_keystreambox->setText(QApplication::translate("MainWindow", "Keystream", 0));
        label_res->setText(QApplication::translate("MainWindow", "Result", 0));
        label_final->setText(QApplication::translate("MainWindow", "Final Result in Hex:", 0));
        pushButton_decipher->setText(QApplication::translate("MainWindow", "Decipher", 0));
        label_decipher->setText(QApplication::translate("MainWindow", "Text to decipher:", 0));
        radioButton_hexa->setText(QApplication::translate("MainWindow", "Hexa", 0));
        radioButton_string->setText(QApplication::translate("MainWindow", "string", 0));
        label_inputmode->setText(QApplication::translate("MainWindow", "Input Mode: ", 0));
        label_inputHex->setText(QApplication::translate("MainWindow", "Text in Hex:", 0));
        label_finalPlain->setText(QApplication::translate("MainWindow", "Final Result in clear text:", 0));
        label_xor1->setText(QApplication::translate("MainWindow", "XOR", 0));
        label_equal1->setText(QApplication::translate("MainWindow", "=", 0));
        label_xor2->setText(QApplication::translate("MainWindow", "XOR", 0));
        label_equal2->setText(QApplication::translate("MainWindow", "=", 0));
        label_xor3->setText(QApplication::translate("MainWindow", "XOR", 0));
        label_equal3->setText(QApplication::translate("MainWindow", "=", 0));
        label_xor4->setText(QApplication::translate("MainWindow", "XOR", 0));
        label_equal4->setText(QApplication::translate("MainWindow", "=", 0));
        pushButton_image->setText(QApplication::translate("MainWindow", "Picture of the process", 0));
        label_image->setText(QString());
        pushButton_back->setText(QApplication::translate("MainWindow", "Retour", 0));
        textBrowser_img0->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8pt;\"><br /></p></body></html>", 0));
        textBrowser_img1->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8pt;\"><br /></p></body></html>", 0));
        textBrowser_img2->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8pt;\"><br /></p></body></html>", 0));
        textBrowser_img3->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8pt;\"><br /></p></body></html>", 0));
        textBrowser_img4->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8pt;\"><br /></p></body></html>", 0));
        textBrowser_img5->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8pt;\"><br /></p></body></html>", 0));
        textBrowser_img6->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\"-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-family:'MS Shell Dlg 2'; font-size:8pt;\"><br /></p></body></html>", 0));
        textBrowser_img7->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">La valeur de i est :</span></p></body></html>", 0));
        textBrowser_img91->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'Sans Serif'; font-size:9pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:8pt;\">La valeur de j est :</span></p></body></html>", 0));
        label_RSA_p->setText(QApplication::translate("MainWindow", "Enter the first prime number:", 0));
        label_RSA_q->setText(QApplication::translate("MainWindow", "Enter the second prime number:", 0));
        label_RSA_M->setText(QApplication::translate("MainWindow", "Enter the message:", 0));
        label_RSA_m->setText(QApplication::translate("MainWindow", "Number m representing the message:", 0));
        label_index->setText(QApplication::translate("MainWindow", "i and j indexes are caculated using the key value", 0));
        label_RSA_n->setText(QApplication::translate("MainWindow", "n = ", 0));
        label_p->setText(QApplication::translate("MainWindow", "TextLabel", 0));
        label_times->setText(QApplication::translate("MainWindow", "X", 0));
        label_q->setText(QApplication::translate("MainWindow", "TextLabel", 0));
        label_eq->setText(QApplication::translate("MainWindow", "=", 0));
        label_pq->setText(QApplication::translate("MainWindow", "TextLabel", 0));
        label_pmoins1->setText(QApplication::translate("MainWindow", "TextLabel", 0));
        label_times_2->setText(QApplication::translate("MainWindow", "X", 0));
        label_pmoins1_res->setText(QApplication::translate("MainWindow", "TextLabel", 0));
        label_eq_2->setText(QApplication::translate("MainWindow", "=", 0));
        label_RSA_phi_n->setText(QApplication::translate("MainWindow", "phi = ", 0));
        label_qmoins1->setText(QApplication::translate("MainWindow", "TextLabel", 0));
        label_eq_3->setText(QApplication::translate("MainWindow", "=", 0));
        label_qmoins1_res->setText(QApplication::translate("MainWindow", "TextLabel", 0));
        label_times_3->setText(QApplication::translate("MainWindow", "X", 0));
        label_phi_n_res->setText(QApplication::translate("MainWindow", "TextLabel", 0));
        label_calcE->setText(QApplication::translate("MainWindow", "Choice of public key:", 0));
        label_calcC->setText(QApplication::translate("MainWindow", "Calculation of the ciphered message:", 0));
        label_RSA_e_in->setText(QApplication::translate("MainWindow", "Enter the public key:", 0));
        label_RSA_c_in->setText(QApplication::translate("MainWindow", "Enter the ciphered message:", 0));
        menuMode->setTitle(QApplication::translate("MainWindow", "Cipher", 0));
        menuAbout->setTitle(QApplication::translate("MainWindow", "About", 0));
        menuMode_2->setTitle(QApplication::translate("MainWindow", "Mode", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
